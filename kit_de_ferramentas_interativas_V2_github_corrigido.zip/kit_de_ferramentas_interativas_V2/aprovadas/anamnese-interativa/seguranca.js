// Compatibilidade local.
